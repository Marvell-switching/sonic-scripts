--------------------------------------------------------------------|----------------------------------
files/202605/PATCH_NAME                                             |submodule-directory
--------------------------------------------------------------------|----------------------------------
0041-buildimage-print-each-build-target-on-separated-line.patch     |sonic-buildimage
0042-grub2-nocheck-no-tests-in-build.patch                          |sonic-buildimage
0064-build_templates-marvell-blacklist-with-kempld.patch            |sonic-buildimage
0031-Falcon-usb-disk-hung_task-WA.patch                             |sonic-buildimage
28251-marvell-prestera-P8.0.0-sai-1.18.1-1.patch                    |sonic-buildimage
28251-marvell-prestera-P8.0.1-sai-1.18.1-11.patch                   |sonic-buildimage
28070-device-Nokia-7215-sai.profile-createSwitchTimeout-180s.patch  |sonic-buildimage
0043-marvell-prestera-rpc-pin-ptf_nn_agent.py-to-use-nnpy.patch     |sonic-buildimage
28010-marvell-platfrom-add-SAI-dependency-to-DOCKER_MGMT_F.patch    |sonic-buildimage
1/1002-vlan1-Yang-changes-to-allow-vlan-1.patch                     |sonic-buildimage

0104-platform-X-arm64-mrvl-pcie-ep-check-reboot-on-EP-miss.patch    |platform/marvell-prestera/mrvl-prestera
0060-sonic-ext.target-wrapper-for-sonic.target.patch                |platform/marvell-prestera/mrvl-prestera
0061-sonic.target-no-install-oveload-for-sonic-ext.target.patch     |platform/marvell-prestera/mrvl-prestera
0013-sonic_installer-add-sync-before-migration.patch                |src/sonic-utilities
1/1001-vlan1-CLI-changes-to-allow-vlan1.patch                       |src/sonic-utilities
1/1003-vlan1-orchagent-changes-to-skip-addition-and-deletio.patch   |src/sonic-swss
