#!/bin/bash

# Copyright (c) Marvell, Inc. All rights reservered. Confidential.
# Description: Applying open PRs needed for compilation
#
# Sonic patch script for Marvell board
#

#
# CONFIGURATIONS:-
#

#
# END of CONFIGURATIONS
#


# PREDEFINED VALUES
CUR_DIR=$(basename `pwd`)
LOG_FILE=build_patches.log
FULL_PATH=`pwd`
err_cnt=0
PATCH_SERIES_FILE=

# VERIFY_PATCHES=Y may be selected by MRVL sonic_build_script.sh
if [[ "$DEVEL" == "" || "$VERIFY_PATCHES" == "Y" ]]; then
  PATCH_ERR_SKIP=
else
  PATCH_ERR_SKIP=Y
fi

log()
{
	echo -e "$@"
	echo -e "$@" >> ${FULL_PATH}/${LOG_FILE}
}

print_usage()
{
	log "Usage:"
	log ""
	log " bash $0 --branch <> --platform <marvell|marvell-prestera|innovium|marvell-teralynx> --arch <amd64|arm64> --release-tag <>"
	log ""
	log ""
}

pre_patch_help()
{
	log "STEPS TO BUILD:"
	log "git clone https://github.com/sonic-net/sonic-buildimage.git -b <sonic_branch>"
	log "cd sonic-buildimage"
	log "<<Apply patches using patch script for sonic-buildimage>>"
	log "make init"
	log "git submodule update --init --recursive (instead of make init)"
	log ""
	log "<<Apply patches using patch script for submodules>>"
	print_usage
	log "PLATFORM: marvell"
	log "<<FOR ARM64>> make configure PLATFORM=marvell PLATFORM_ARCH=arm64"
	log "<<FOR ARM64>> make target/sonic-marvell-arm64.bin"
	log "<<FOR INTEL>> make configure PLATFORM=marvell"
	log "<<FOR INTEL>> make target/sonic-marvell.bin"
	log ""
	log "PLATFORM: innovium"
	log "<<FOR INTEL>> make configure PLATFORM=innovium"
	log "<<FOR INTEL>> make target/sonic-innovium.bin"
	log ""
	log "PLATFORM: marvell-teralynx"
	log "<<FOR INTEL>> make configure PLATFORM=marvell-teralynx"
	log "<<FOR INTEL>> make target/sonic-marvell-teralynx.bin"
	log ""
}

parse_arguments()
{
	while [[ $# -gt 0 ]]; do
		case $1 in
			-b|--branch)
				BRANCH="$2"
				shift # past argument
				shift # past value
				;;
			-p|--platform)
				PLATFORM="$2"
				shift # past argument
				shift # past value
				;;
			-a|--arch)
				ARCH="$2"
				shift # past argument
				shift # past value
				;;
			-t|--release-tag)
				GIT_TAG="$2"
				shift # past argument
				shift # past value
				;;
			--url)
				URL="$2"
				shift # past argument
				shift # past value
				;;
			-h|--help)
				print_usage
				exit 0
				;;
			*)
				echo "ERROR: Unknown option '$1'"
				print_usage
				exit 1
				;;
		esac
	done

	if [ -z "${BRANCH}" ]; then
		echo "Branch is not set. Please check usage."
		print_usage
		exit 0
	fi

	if [ -z "${ARCH}" ]; then
		echo "Arch is not set. Please check usage."
		print_usage
		exit 0
	fi

	if [[ -z "${GIT_TAG}" && -z "${URL}" ]]; then
		echo "Github release tag is not set. Please check usage."
		print_usage
		exit 0
	fi

	if [ -z "${PLATFORM}" ]; then
		echo "Platform is not set. Please check usage."
		print_usage
		exit 0
	fi

	if [ -z "${URL}" ]; then
		WGET_PATH="https://raw.githubusercontent.com/Marvell-switching/sonic-scripts/$GIT_TAG/files/$BRANCH/"
	else
		WGET_PATH=$URL/files/$BRANCH
	fi
}

wget_cp()
{
    if [[ "$1" == *:* ]]; then
        # Is URL - use wget      -P dstDir
        # wget --timeout=2 -c $1  $2 $3
        local url="$1"
        if [ "$2" = "-P" ] && [ -n "$3" ]; then
            curl --connect-timeout 2 --speed-time 2 --speed-limit 1 -C - -fsSL \
                -o "$3/$(basename "$url")" "$url"
        else
            curl --connect-timeout 2 --speed-time 2 --speed-limit 1 -C - -fsSLO "$url"
        fi
    else
        # Dir or File is on local path
        dstDir="${3:-.}"
        cp -r $1 $dstDir
    fi
}

wget_cp_silent()
{
    if [[ "$1" == *:* ]]; then
        # Is URL - use wget      -P dstDir
        # wget --timeout=2 -c $1  $2 $3  2>/dev/null
        local url="$1"
        if [ "$2" = "-P" ] && [ -n "$3" ]; then
            curl --connect-timeout 2 --speed-time 2 --speed-limit 1 -C - -fsSL \
                -o "$3/$(basename "$url")" "$url" 2>/dev/null
        else
            curl --connect-timeout 2 --speed-time 2 --speed-limit 1 -C - -fsSLO "$url" 2>/dev/null
        fi
    else
        # Dir or File is on local path
        dstDir="${3:-.}"
        cp -r $1 $dstDir  2>/dev/null
    fi
}

apply_sonicbuildimage_patches()
{
 SERIES_FILE=$1
 CSD=$2
 PATCH_DIR=patches/$CSD
 if [ ! -f "$PATCH_DIR/$SERIES_FILE" ]; then
	log "ERROR: $PATCH_DIR/$SERIES_FILE file not found"
    exit 1
 fi
 cat $PATCH_DIR/$SERIES_FILE | grep -v -E '^#|^$' | grep sonic-buildimage | cut -f 1 -d'|' | while read -r patch_file
 do
	echo $patch_file
	pushd $PATCH_DIR
	wget_cp $WGET_PATH/$CSD/$patch_file
	popd
	git am $PATCH_DIR/$patch_file
	ret=$?
	if [ $ret -ne 0 ]; then
        ((err_cnt++))
		if [ "$PATCH_ERR_SKIP" == "" ]; then
			log "PATCH ERROR: Failed to apply sonicbuildimage $PATCH_DIR/$patch_file, abort"
			return $ret
		fi
		log "PATCH ERROR: Failed to apply sonicbuildimage $PATCH_DIR/$patch_file, skeep and continue"
		git am --skip
	else
		log "${patch_file} \t\t applied in <root>/"
	fi
 done
}

apply_submodule_patches()
{
 SERIES_FILE=$1
 CSD=$2
 PATCH_DIR=patches/$CSD
 CWD=`pwd`
 cat $PATCH_DIR/$SERIES_FILE | grep -v -E '^#|^$' | grep -v sonic-buildimage | while read -r line
 do
	patch=`echo $line | cut -f 1 -d'|'`
	dir=`echo $line | cut -f 2 -d'|'`
	pushd $PATCH_DIR
	wget_cp $WGET_PATH/$CSD/${patch}
	popd
	pushd ${dir}
	git am $CWD/$PATCH_DIR/${patch}
	ret=$?
	if [ $ret -ne 0 ]; then
        ((err_cnt++))
		if [ "$PATCH_ERR_SKIP" == "" ]; then
			log "PATCH ERROR: Failed to apply submodule $CWD/$PATCH_DIR/${patch}, abort"
			return $ret
		fi
		log "PATCH ERROR: Failed to apply submodule $CWD/$PATCH_DIR/${patch}, skeep and continue"
		git am --skip
	else
		log "${patch} \t\t applied in ${dir}"
	fi
	popd
 done
}

prestera_hwsku_fetch_tgz()
{
    local base="$1"
    local got_tgz=
    local try

    if [ -n "$SAI_DEB_DIR" ] && [ -n "$SAI_HWSKU_VER" ]; then
        try="${base}-${SAI_HWSKU_VER}.tgz"
        wget_cp "$SAI_DEB_DIR/$try" -P ./patches/
        if [ $? -eq 0 ] && [ -f "./patches/$try" ]; then
            got_tgz=$try
        fi
    fi
    if [ -z "$got_tgz" ] && [ -n "$SAI_DEB_DIR" ]; then
        try="${base}.tgz"
        wget_cp "$SAI_DEB_DIR/$try" -P ./patches/
        if [ $? -eq 0 ] && [ -f "./patches/$try" ]; then
            got_tgz=$try
        fi
    fi
    if [ -z "$got_tgz" ] && [ -n "$SAI_HWSKU_VER" ]; then
        try="${base}-${SAI_HWSKU_VER}.tgz"
        wget_cp $WGET_PATH/$try -P ./patches/
        if [ $? -eq 0 ] && [ -f "./patches/$try" ]; then
            got_tgz=$try
        fi
    fi
    if [ -z "$got_tgz" ]; then
        try="${base}.tgz"
        wget_cp $WGET_PATH/$try -P ./patches/
        if [ $? -eq 0 ] && [ -f "./patches/$try" ]; then
            got_tgz=$try
        fi
    fi
    echo "$got_tgz"
}

apply_hwsku_changes()
{
    if [ "$PLATFORM" == "marvell" ] || [ "$PLATFORM" == "marvell-prestera" ]; then
        HWSKU_NAME=prestera_hwsku
        SAI_DEB_DIR=
        SAI_HWSKU_VER=
        if [ -n "$SAI_URL_PATH" ]; then
            SAI_DEB_DIR=$(dirname "$SAI_URL_PATH")
            SAI_HWSKU_VER=$(basename "$SAI_URL_PATH" | sed -E 's/^mrvllibsai_([0-9]+\.[0-9]+\.[0-9]+-[0-9]+)_.*\.deb$/\1/')
        fi
        if [ -n "$SAI_SET_ESAI" ]; then
            HWSKU_TGZ=$(prestera_hwsku_fetch_tgz "${HWSKU_NAME}-esai")
            if [ -n "$HWSKU_TGZ" ]; then
                ## # Cleanup .tgz below second-level directories before extracting
                ## tar -tf ./patches/$HWSKU_TGZ | awk -F/ 'NF>=2 {print $1 "/" $2}' | sort -u |
                ##     while read dir; do
                ##         find "device/$dir" -mindepth 1 \( -type f -o -type l \) -delete
                ##     done
                tar -C device/ -xzf ./patches/$HWSKU_TGZ
            else
                log "ERROR: eSAI build must have $HWSKU_NAME-esai.tgz"
                exit 1
            fi
        else
            HWSKU_TGZ=$(prestera_hwsku_fetch_tgz "$HWSKU_NAME")
            if [ -n "$HWSKU_TGZ" ]; then
                rm -fr device/marvell/x86_64-marvell_db* || true
                tar -C device/ -xzf ./patches/$HWSKU_TGZ
            fi
        fi
    fi
    if [ "$PLATFORM" == "innovium" ] || [ "$PLATFORM" == "marvell-teralynx" ]; then
        wget_cp $WGET_PATH/teralynx_hwsku.tgz -P ./patches/
        if [ $? -eq 0 ]; then
            rm -fr device/celestica/x86_64-cel_midstone-r0 || true
            rm -fr device/wistron || true
            tar -C device/ -xzf ./patches/teralynx_hwsku.tgz
        fi
    fi
}

main()
{
	if [ "$CUR_DIR" != "sonic-buildimage" ]; then
		log "ERROR: Need to be at sonic-builimage git clone path"
		pre_patch_help
		exit 1
	fi
	parse_arguments $@

	date > ${FULL_PATH}/${LOG_FILE}
	[ -d patches ] || mkdir patches

	# wget patch series file
    PATCH_SERIES_FILE=series_${PLATFORM}_${ARCH}
	wget_cp_silent $WGET_PATH/${PATCH_SERIES_FILE} -P ./patches/
	if [ ! -f ./patches/${PATCH_SERIES_FILE} ]; then
		PATCH_SERIES_FILE=series_${PLATFORM}
		wget_cp $WGET_PATH/${PATCH_SERIES_FILE} -P ./patches/
		if [ ! -f ./patches/${PATCH_SERIES_FILE} ]; then
			log "ERROR: Series file series_${PLATFORM} not found"
		    exit 1
		fi
	fi

    log "\n Apply patches on top of SONIC-buildimage commit\n"
    log "  ${UPSTREAM_COMMIT}\n"

	# ----- Apply patches -------------------------------
	log "\n--- Apply sonicbuildimage patches -----\n"
    CSD=.
	apply_sonicbuildimage_patches $PATCH_SERIES_FILE "$CSD" || exit 1

    # CSD - Customer-Set-Directory
    CSD_LIST="tl 1 2 3"
    if [ -n "$SAI_SET_ESAI" ]; then
        # Check PATCH_CUSTOM_ESAI presence since they are optional
        CSD=esai
        mkdir -p ./patches/$CSD
        wget_cp_silent $WGET_PATH/$CSD/series -P ./patches/$CSD
        if [ -f ./patches/$CSD/series ]; then
            CSD_LIST="$CSD_LIST $CSD"
            PATCH_CUSTOM_ESAI="Y"
            rm ./patches/$CSD/series
        fi
    fi

    for CSD in $CSD_LIST; do
        case "$CSD" in
          esai) var="PATCH_CUSTOM_ESAI" ;;
            tl) var="PATCH_CUSTOM_TL" ;;
            *)  var="PATCH_CUSTOM_${CSD}" ;;
        esac
        [ "${!var}" = "Y" ] || continue
        mkdir -p ./patches/$CSD
        wget_cp $WGET_PATH/$CSD/series -P ./patches/$CSD
        apply_sonicbuildimage_patches series "$CSD" || exit 1
    done

	echo "\n--- make init -----------"
	echo "make init" >> build_cmd.txt
	make init
	git submodule sync --recursive
	git submodule update --init --recursive

	log "\n--- Apply submodule patches ---\n"
	# Apply submodule patches
    CSD=.
	apply_submodule_patches $PATCH_SERIES_FILE "$CSD" || exit 1

    for CSD in $CSD_LIST; do
        case "$CSD" in
          esai) var="PATCH_CUSTOM_ESAI" ;;
            tl) var="PATCH_CUSTOM_TL" ;;
            *)  var="PATCH_CUSTOM_${CSD}" ;;
        esac
        [ "${!var}" = "Y" ] || continue
        apply_submodule_patches series "$CSD" || exit 1
    done

	log "\n--- Apply hwsku changes ---\n"
	# Apply hwsku changes
	apply_hwsku_changes
	log "Patch script - DONE"
}

main $@
