SAI_INIT_CONFIG_FILE=/usr/share/sonic/hwsku/esai_config_ac5x_sim.xml
switchMacAddress=00:01:02:03:04:05
createSwitchTimeout=150
