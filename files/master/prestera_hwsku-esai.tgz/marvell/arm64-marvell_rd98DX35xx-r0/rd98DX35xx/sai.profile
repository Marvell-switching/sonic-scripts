mode=1
hwId=AC5XRD
SAI_INIT_CONFIG_FILE=/usr/share/sonic/hwsku/esai_config_ac5x_rd_int.xml
switchMacAddress=00:01:02:03:04:05
createSwitchTimeout=150
