mode=1
pci_id=9805
device_id=AC5X_RD_ext
SAI_INIT_CONFIG_FILE=/usr/share/sonic/hwsku/esai_config_ac5x_rd_ext.xml
switchMacAddress=00:01:02:03:04:05
createSwitchTimeout=150
