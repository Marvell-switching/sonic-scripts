mode=1
hwId=AC5P-RD
SAI_INIT_CONFIG_FILE=/usr/share/sonic/hwsku/esai_config_ac5p_rd_ext.xml
switchMacAddress=00:01:02:03:04:05
createSwitchTimeout=120
