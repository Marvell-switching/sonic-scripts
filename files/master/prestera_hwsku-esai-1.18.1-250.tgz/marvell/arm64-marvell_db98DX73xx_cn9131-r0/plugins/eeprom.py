#!/usr/bin/env python
#
# Copyright (c) 2026 Marvell or its affiliates. All rights reserved.
# Unless otherwise expressly stated, this source code is licensed
# pursuant to the Marvell Limited Use License Agreement (LULA):
# https://www.marvell.com/agreement.html
# SPDX-License-Identifier: LicenseRef-Proprietary-Marvell

try:
    from sonic_eeprom import eeprom_tlvinfo
except ImportError as e:
    raise ImportError (str(e) + "- required module not found")


class board(eeprom_tlvinfo.TlvInfoDecoder):

    def __init__(self, name, path, cpld_root, ro):
        self.eeprom_path = "/sys/bus/i2c/devices/0-0050/eeprom"
        super(board, self).__init__(self.eeprom_path, 0, '', True)
